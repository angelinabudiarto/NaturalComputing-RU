# Artistoo (Artificial Tissue Toolbox)

This manual is under construction. It currently contains some basic instructions
on how to get started, but stay tuned for the most recent version! In
the meantime, see the [examples](./examples.html)
(with provided [code](https://github.com/ingewortel/artistoo/tree/master/examples))
and the full [method documentation](./identifiers.html)
to get an idea of what you can do with Artistoo.





