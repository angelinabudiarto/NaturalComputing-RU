echo "<script>"
echo "MathJax = {"
echo -e "\ttex: {"
echo -e "\t\tinlineMath: [['$', '$']]"
echo -e "\t"}
echo "};"
echo "</script>"
echo "<script src=\"https://polyfill.io/v3/polyfill.min.js?features=es6\"></script>"
echo "<script id=\"MathJax-script\" async src=\"https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js\"></script>"